// program for addition of two numbers
#include<stdio.h>
int main()
{
 int a,b,c;
 
 printf("enter two number");
 scanf("%d %d", &a, &b);
 //calc. sum
 c = a + b;
 printf("%d + %d = %d", a,b,c);
return 0;
}