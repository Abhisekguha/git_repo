#include <stdio.h> 
void main()
{
int c=2,d=5; 
printf("%d\n",c++);     //displays 2 then, only c incremented by 1 to 3.
printf("%d\n",d--);     //displays 5 then, only d decremented by 1 to 4.
printf("%d\n",++c);       //increments 1 to c then, only c is displayed.
printf("%d",--d);       //decrements 1 to d then, only d is displayed.

}
