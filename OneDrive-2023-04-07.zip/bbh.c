#include<stdio.h>
int main()
{
      printf("bros before hoes\n");
      return 0;
}