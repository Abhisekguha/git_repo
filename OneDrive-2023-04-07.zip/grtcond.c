//greatest int among three no.s using cond opp.
#include<stdio.h>
void main()
{
 int a,b,c,big;
 printf("enter three nos.");
 scanf("%d %d %d", &a, &b, &c);
 big=a>c? (a>c? a:c):(b>c? b:c);
 printf("\n the biggest number is %d");
}
