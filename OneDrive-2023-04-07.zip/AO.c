// program for arithematic operator
#include<stdio.h>
void main()
{
 int a,b,add,sub,div,mul,mod;
 printf("enter two numbers");
 scanf("%d %d", &a, &b);
 //calculation 
 
 add=a+b;
 sub=a-b;
 div=a/b;
 mul=a*b;
 mod=a%b;
 
 printf("add a,b = %d\n",add);
 printf("sub a,b = %d\n",sub);
 printf("div a,b = %d\n",div);
 printf("mul a,b = %d\n",mul);
 printf("mod a,b = %d\n",mod);
}