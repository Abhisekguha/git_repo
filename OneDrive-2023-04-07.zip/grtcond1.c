//greatest int among three no.s using cond opp.
#include<stdio.h>
void main()
{
 int a=2 ,b=3, c=4 ,big;
 big=a>c? (a>c? a:c):(b>c? b:c);
 printf("\n the biggest number is %d");
}
