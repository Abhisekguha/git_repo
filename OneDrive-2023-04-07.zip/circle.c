//prog to find the area and circumference of a circle
#include<stdio.h>
void main()
{
 int rad;
 float pi = 3.14 , area, circumference;
 printf("enter the radius of circle : \n");
 scanf("%d", &rad);

 //calc
 area = pi*rad*rad;
 printf("\n area of a circle of radius %d is %f", rad, area);

 circumference = 2*pi*rad;
 printf("\n circumference of a circle of radius %d is %f", rad, circumference);
} 
 