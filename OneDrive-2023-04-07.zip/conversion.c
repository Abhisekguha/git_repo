//program to convert temp. from celsius to fahrenheit or vice versa
#include<stdio.h>
void main()
{
	float c,f;
	char a;
	printf("enter character 'c' to convert temp. from celsius to fahrenheit \n and 'f' for fahrenheit to celsius\n  ");
	scanf("%c",&a);
	if (a=='c')
	{
		printf("enter the temp. in celsius = ");
		scanf("%f",&c);
		f=1.8*c+32;
		printf("temp. in fahrenheit = %f",f);
	}
	else if (a=='f')
	{
		printf("enter the temp. in fahrenheit = ");
		scanf("%f",&f);
		c=(f-32)*5/9;
		printf("temp. in celsius = %f",c);
	}
	else
	printf("wrong character");
}