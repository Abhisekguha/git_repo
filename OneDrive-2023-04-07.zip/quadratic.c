// Program to find roots of the quadratic equation

#include <math.h>    // pow() and sqrt() is used in the program hence math.h header file is included
#include <stdio.h>   // stdio.h header file is used for printf() anf scanf()
int main() 
{
    double a, b, c, discriminant, root1, root2, realPart, imagPart;
    printf("Enter coefficients a, b and c: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    discriminant = pow(b,2) - 4 * a * c;     // pow() is used to find "square of b" 
  
    // or you can use simple statement also as below
   // discriminant = b * b - 4 * a * c;

    // condition for real and different roots
    if (discriminant > 0) 
    {
        root1 = (-b + sqrt(discriminant)) / (2 * a);     // sqrt() is used to find "square root" of the discriminant
        root2 = (-b - sqrt(discriminant)) / (2 * a);
        printf("root1 = %.2lf and root2 = %.2lf", root1, root2);
    }

    // condition for real and equal roots
    else if (discriminant == 0) {
        root1 = root2 = -b / (2 * a);
        printf("root1 = root2 = %.2lf;", root1);
    }

    // if roots are not real
    else 
    {
        realPart = -b / (2 * a);
        imagPart = sqrt(-discriminant) / (2 * a);
        printf("root1 = %.2lf + %.2lfi and root2 = %.2f - %.2fi", realPart, imagPart, realPart, imagPart);
    }

    return 0;
} 
